export default function Page() {
  return (
    <div className="py-8">
      <div className="card p-6">
        <h2 className="text-xl font-semibold capitalize">positions</h2>
        <p className="opacity-70 text-sm mt-2">Coming soon in MVP build.</p>
      </div>
    </div>
  );
}
