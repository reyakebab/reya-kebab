import { SwapCard } from "@/components/SwapCard";

export default function Page() {
  return (
    <div className="py-8">
      <SwapCard />
    </div>
  );
}
